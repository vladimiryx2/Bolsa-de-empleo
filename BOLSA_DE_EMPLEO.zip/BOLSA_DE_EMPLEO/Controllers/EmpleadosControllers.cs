

using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BOLSA_DE_EMPLEO.Data;
using BOLSA_DE_EMPLEO.Models;


namespace BOLSA_DE_EMPLEO.Controllers{
    public class EmpleadosController : Controller
    {
        public readonly BaseContext _context;

        public EmpleadosController(BaseContext context)
        {
            _context = context;
        }

        // LIST ALL USERS
        public async Task<IActionResult>Index(){
            return View(await _context.Empleados.ToListAsync());
        }

       

        // DEFINIMOS DETALLES
          public async Task<IActionResult> Details(int? id){
            return View(await _context.Empleados.FirstOrDefaultAsync(m=>m.Id == id));
            
        }

        //DEFINIMOS CREATE
         public IActionResult Create(){
            return View();
        }
        [HttpPost]
           public async Task<IActionResult> Create(Empleado E){
          _context.Empleados.Add(E);
          _context.SaveChanges();
          return RedirectToAction("Index");
        }


        //DEFINIMOS EDIT
        public async  Task<IActionResult> Edit(int id){
            return View(await _context.Empleados.FirstOrDefaultAsync(m=>m.Id == id));
        }
        [HttpPost]
        public  IActionResult Edit(Empleado E, int Id ){
            _context.Empleados.Update(E);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }

        
        //DEFINIMOS DELETE
       public async Task<IActionResult> Delete(int? Id)
        {
            var Empleado = await _context.Empleados.FindAsync(Id);
            _context.Empleados.Remove(Empleado);
            await _context.SaveChangesAsync();
            return RedirectToAction("Index");
        } 

        //DEFINIMOS LA BUSQUEDA
         public IActionResult Search(string searchString, object J)
        {
            var Empleado = _context.Empleados.AsQueryable();
            if (!string.IsNullOrEmpty(searchString))
            {
             Empleado = Empleado.Where(E => E.Nombres.Contains(searchString) || E.Apellidos.Contains(searchString) || E.Correo.Contains(searchString)|| E.Genero.Contains(searchString)|| E.Estado_Civil.Contains(searchString)|| E.Idiomas.Contains(searchString));
            }
            return View("Index",Empleado.ToList());
        }        
        
    }
}