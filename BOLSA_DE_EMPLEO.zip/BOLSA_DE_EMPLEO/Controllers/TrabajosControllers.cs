

using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BOLSA_DE_EMPLEO.Data;
using BOLSA_DE_EMPLEO.Models;


namespace BOLSA_DE_EMPLEO.Controllers{
    public class TrabajosController : Controller
    {
        public readonly BaseContext _context;

        public TrabajosController(BaseContext context)
        {
            _context = context;
        }

        // LIST ALL USERS
        public async Task<IActionResult>Index(){
            return View(await _context.Trabajos.ToListAsync());
        }

       

        // DEFINIMOS DETALLES
          public async Task<IActionResult> Details(int? id){
            return View(await _context.Trabajos.FirstOrDefaultAsync(m=>m.Id == id));
            
        }

        //DEFINIMOS CREATE
         public IActionResult Create(){
            return View();
        }
        [HttpPost]
           public async Task<IActionResult> Create(Trabajo T){
          _context.Trabajos.Add(T);
          _context.SaveChanges();
          return RedirectToAction("Index");
        }


        //DEFINIMOS EDIT
        public async  Task<IActionResult> Edit(int id){
            return View(await _context.Trabajos.FirstOrDefaultAsync(m=>m.Id == id));
        }
        [HttpPost]
        public  IActionResult Edit(Trabajo T, int Id ){
            _context.Trabajos.Update(T);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }

        
        //DEFINIMOS DELETE
       public async Task<IActionResult> Delete(int? Id)
        {
            var Trabajo = await _context.Trabajos.FindAsync(Id);
            _context.Trabajos.Remove(Trabajo);
            await _context.SaveChangesAsync();
            return RedirectToAction("Index");
        } 

        //DEFINIMOS LA BUSQUEDA
         public IActionResult Search(string searchString, object J)
        {
            var Trabajo = _context.Trabajos.AsQueryable();
            if (!string.IsNullOrEmpty(searchString))
            {
             Trabajo = Trabajo.Where(T => T.NombreEmpresa.Contains(searchString) || T.Titulo_Vacante.Contains(searchString) || T.Pais.Contains(searchString)|| T.Estado.Contains(searchString)|| T.Titulo_Vacante.Contains(searchString)|| T.Idiomas.Contains(searchString));
            }
            return View("Index",Trabajo.ToList());
        }        
        
    }
}