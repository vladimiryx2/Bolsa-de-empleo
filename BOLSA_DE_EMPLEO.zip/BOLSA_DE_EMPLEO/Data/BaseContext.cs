using Pomelo.EntityFrameworkCore.MySql;
using Microsoft.EntityFrameworkCore;
using BOLSA_DE_EMPLEO.Models;

namespace BOLSA_DE_EMPLEO.Data
{
    public class BaseContext : DbContext
    {
        public BaseContext(DbContextOptions<BaseContext> options): base(options){

        }
        public DbSet <Trabajo> Trabajos { get; set; }
       public DbSet <Empleado> Empleados { get; set; }
        //public DbSet <Sector> Sectors { get; set; }
    }
}
   
