using System.Numerics;

namespace BOLSA_DE_EMPLEO.Models
{
    public class Empleado
    {
       public int Id { get; set; }
       public string? Nombres { get; set; }
       public string? Apellidos { get; set; } 
       public string? Correo { get; set; }
       public DateOnly? Fecha_Nacimiento { get; set; }
       public string? Foto_Perfil { get; set; }
       public string? Cv { get; set; }
       public string? Genero { get; set; }
       public string? Telefono { get; set; }
       public string? Direccion { get; set; }
       public string? Estado_Civil { get; set; }
       public double? Salario { get; set; }
       public string? Descripcion { get; set; }
       public string? Titulos_Academicos { get; set; }
       public string? Idiomas { get; set; }
       public string? Area { get; set; }
    }
}
/*
create table Empleados(
ID INT primary key auto_increment,
Nombres VARCHAR(45), 
Apellidos VARCHAR(45),
Correo VARCHAR (125) unique,
Fecha_Nacimiento date,
Foto_Perfil VARCHAR(255),
Cv VARCHAR(255),
Genero VARCHAR(45),
Telefono VARCHAR(45),
Direccion VARCHAR(125),
Estado_Civil VARCHAR(45),
Salario double,
Descripcion VARCHAR(255),
Titulos_Academicos VARCHAR(125),
Idiomas VARCHAR(125),
Area VARCHAR(45)
);*/
