using System.Numerics;

namespace BOLSA_DE_EMPLEO.Models
{
    public class Trabajo
    {
       public int Id { get; set; }
       public string? NombreEmpresa { get; set; }
       public string? Logo { get; set; } 
       public string? Titulo_Vacante { get; set; }
       public string? Descripcion { get; set; }
       public double? Salario { get; set; }
       public string? Cargo { get; set; }
       public string? Estado { get; set; }
       public string? Pais { get; set; }
       public string? Idiomas { get; set; }
    }
}









/*Id bigint(20) UN AI PK 
Name varchar(255) 
Nit varchar(255) 
Address varchar(255) 
Description text 
Logo text 
Phone text 
LegalRepresentative varchar(255) 
SectorId bigint(20) UN 
created_at timestamp 
updated_at timestamp*/